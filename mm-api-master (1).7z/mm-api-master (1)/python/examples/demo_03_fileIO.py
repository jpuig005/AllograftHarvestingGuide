# demo read/write of .MIX files
#import file

import os

import sys
sys.path.insert(0, 'C:\Users\jpuig005\Google Drive\UPF-Enginyeria Biomedica\TFG\Software\Meshmixer API\mm-api-master (1)\distrib\python')

import mmapi
from mmRemote import *

sys.path.insert(0, 'C:\Users\jpuig005\Google Drive\UPF-Enginyeria Biomedica\TFG\Software\Meshmixer API\mm-api-master (1)\python')

import mm


# initialize connection
remote = mmRemote()
remote.connect()

# run commands

examples_dir = os.getcwd()
mm.open_mix(remote, os.path.join( examples_dir, "sphere.mix" ))
mm.save_mix(remote, os.path.join( examples_dir, "sphere.sphere_exported" ))

#done!
remote.shutdown()



