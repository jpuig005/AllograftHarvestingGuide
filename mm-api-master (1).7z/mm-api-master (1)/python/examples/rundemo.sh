#!/bin/bash

export PYTHONPATH=$PYTHONPATH:../../distrib/python_osx/:..

python $1