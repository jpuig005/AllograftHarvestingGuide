# Demo running Overhangs tool and generating a 3D-printing support structure

import sys
sys.path.insert(0, 'C:\Users\jpuig005\Google Drive\UPF-Enginyeria Biomedica\TFG\Software\Meshmixer API\mm-api-master (1)\distrib\python')

#import file
import mmapi
from mmRemote import *

sys.path.insert(0, 'C:\Users\jpuig005\Google Drive\UPF-Enginyeria Biomedica\TFG\Software\Meshmixer API\mm-api-master (1)\python')

import mm


# initialize connection
remote = mmRemote()
remote.connect()

# start overhangs tool
mm.begin_tool(remote, "overhangs")
# generate support structure
mm.tool_utility_command(remote, "generateSupport")
# convert support to solid
mm.tool_utility_command(remote, "convertToSolid", 0)
# done!
mm.accept_tool(remote)

remote.shutdown()



