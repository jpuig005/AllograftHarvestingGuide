# selection examples:
#   - list selected objects
#   - list selected facegroups

import sys
sys.path.insert(0, 'C:\Users\jpuig005\Google Drive\UPF-Enginyeria Biomedica\TFG\Software\Meshmixer API\mm-api-master (1)\distrib\python')

#import file
import mmapi
from mmRemote import *

sys.path.insert(0, 'C:\Users\jpuig005\Google Drive\UPF-Enginyeria Biomedica\TFG\Software\Meshmixer API\mm-api-master (1)\python')

import mm

# initialize connection
remote = mmRemote()
remote.connect()

# print list of selected object IDs
selected_objects = mm.list_selected_objects(remote)
print "selected objects: ", selected_objects

# print list of selected group IDs (empty if no selection)
groups_list = mm.list_selected_groups(remote)
print "selected groups: ", groups_list

#done!
remote.shutdown()



