// [RMS] StoredCommands.cpp uses these symbols

namespace rms {
	class BinarySerializer;
}


static void lgDevelBreak()
{
}

#define lgRASSERT(x)

